#!/bin/bash
python3 /shared/controller.py --p4info /shared/l2_basic_forwarding.p4info.txt --bmv2-json /shared/l2_basic_forwarding.json
