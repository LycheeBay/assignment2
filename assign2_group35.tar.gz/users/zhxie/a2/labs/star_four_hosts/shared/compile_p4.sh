#!/bin/bash
p4c --p4runtime-files /shared/l2_basic_forwarding.p4info.txt /shared/l2_basic_forwarding.p4
