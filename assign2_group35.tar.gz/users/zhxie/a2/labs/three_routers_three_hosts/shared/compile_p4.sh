p4c --p4runtime-files /shared/l3_static_routing.p4info.txt /shared/l3_static_routing.p4
