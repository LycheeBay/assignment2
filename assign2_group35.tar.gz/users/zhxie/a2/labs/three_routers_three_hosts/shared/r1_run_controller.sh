#!/bin/bash
python3 /shared/controller.py --p4info /shared/l3_static_routing.p4info.txt --bmv2-json /shared/l3_static_routing.json --routing-info /shared/r1_routing_info
