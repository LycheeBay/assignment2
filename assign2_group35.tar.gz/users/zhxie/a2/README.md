This is a skeleton code for CS356 assignment 2.
